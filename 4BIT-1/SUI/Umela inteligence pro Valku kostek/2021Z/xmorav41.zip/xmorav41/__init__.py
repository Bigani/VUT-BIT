from .phased import FinalAI as AI
import PyQt5
import sys
sys.path.append("../xmorav41")
import cnn
