source ../env-sui/bin/activate
export PYTHONPATH=$PWD:$PYTHONPATH
