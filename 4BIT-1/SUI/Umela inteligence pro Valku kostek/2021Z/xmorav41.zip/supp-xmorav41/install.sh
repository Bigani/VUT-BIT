#!/usr/bin/env bash

python3 -m venv ../env-sui
source ../env-sui/bin/activate
pip install -r requirements.txt
