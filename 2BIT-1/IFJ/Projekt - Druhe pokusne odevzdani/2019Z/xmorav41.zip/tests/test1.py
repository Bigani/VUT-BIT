a = inputi()
if a >= 10:
  if a == 10:
    print('hodnota', a, 'se rovna 10')
  else:
    print('hodnota', a, 'je vetsi jak 10')
else:
  print('hodnota', a, 'je mensi jak 10')
