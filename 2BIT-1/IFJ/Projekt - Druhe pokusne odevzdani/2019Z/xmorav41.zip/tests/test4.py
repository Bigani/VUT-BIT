a = 0
b = 441
print('budes stuck v cyklu, dokud neuhadnes cislo v rozmezi 0 - 1 000')
while a != b:
  a = inputi()
  if a != b:
    print('zadana hodnota', a, 'neni pozadovana hodnota')
  else:
    print('nyni si pravy programator')