a = inputs()
b = len(a)
print('delka vlozeneho stringu', a, 'je', b)
