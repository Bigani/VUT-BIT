package com.example.itu10;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.graphics.Color;
import android.os.Bundle;

import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;


import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{ //hlavní soubor programu, zajišťuje funkcionalitu toho, co funguje, přepínání záložek atd

    Toolbar toolbartab;
    ViewPager viewPager;
    TabLayout tabLayout;
    PageAdapter pageAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbartab=(Toolbar) findViewById(R.id.toolbartab);
        viewPager=(ViewPager) findViewById(R.id.viewpager);
        tabLayout=(TabLayout) findViewById(R.id.tablayout);

        pageAdapter=new PageAdapter(getSupportFragmentManager()); //vložení záložek při spuštění
        pageAdapter.addFragment(new FavsFragment(), "Oblíbené");
        pageAdapter.addFragment(new MetroFragment(), "Metronom");
        pageAdapter.addFragment(new SettingsFragment(), "Nastavení");

        viewPager.setAdapter(pageAdapter);
        viewPager.setCurrentItem(1); //aplikace se otevře na 2 položce = metronom

        getWindow().setStatusBarColor(Color.parseColor("#AED581")); //správné barvy při spuštění
        toolbartab.setBackgroundColor(Color.parseColor("#AED581"));
        tabLayout.setBackgroundColor(Color.parseColor("#AED581"));

        tabLayout.setupWithViewPager(viewPager);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { //přepnutí barev při změnění záložky
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition())
                {
                    case 1:
                        getWindow().setStatusBarColor(Color.parseColor("#AED581"));
                        toolbartab.setBackgroundColor(Color.parseColor("#AED581"));
                        tabLayout.setBackgroundColor(Color.parseColor("#AED581"));
                        break;

                    default:
                        getWindow().setStatusBarColor(Color.parseColor("#81C784"));
                        toolbartab.setBackgroundColor(Color.parseColor("#81C784"));
                        tabLayout.setBackgroundColor(Color.parseColor("#81C784"));
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { //přepínání toho nahoře při slidování záložek
        String text = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }
}
