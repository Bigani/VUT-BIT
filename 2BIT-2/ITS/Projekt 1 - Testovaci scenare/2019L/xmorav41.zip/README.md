## Testovacie scenáre k 1. projektu do ITS 2019/2020
Jméno a příjmení: Tomáš Moravčík
Login: xmorav41

### Cieľ testov:
___
Testy sú zamerané na kontrolu funckionality užívateľských možností v rámci stránky

### Testy 
***
Súbor obsahuje 21 užívateľsky založených scenárov BDD:
___
1. Test - Registrácia užívateľa
___
2. Test - Prístup neregistrovaného užívateľa k stránkam účtu
___
3. Test - Zmena osobných informácii účtu
___
4. Test - Dotaz užívateľa
___
5. Test - Zmena hesla
___
6. Test - Zabudnuté heslo (platný email)
___
7. Test - Zabudnuté heslo (neplatný email)
___
8. Test - Odstránenie adresy
___
9. Test - Odstránenie predvolenej adresy
___
10. Test - Generovanie odkazu na produkt v partnerskom účte
___
11. Test - Zmena odosielania príspevkov na email
___
12. Test - Odhlásenie užívateľa
___
13. Test - Zachovanie produktov v košíku
___
14. Test - Informácie o stornovaní produktu
___
15. Test - Pridanie do zoznamu želaní
___
16. Test - Odstránenie zo zoznamu želaní
___
17. Test - Neplatný košík (kvantita)
___
18. Test - Korektná platba 
___
19. Test - Nekorektná platba (nedostupný produkt)
___
20. Test - Nekorektná platba (prázdny košík)
___
21. Test - Nekorektná platba (zmena v košíku)
___

