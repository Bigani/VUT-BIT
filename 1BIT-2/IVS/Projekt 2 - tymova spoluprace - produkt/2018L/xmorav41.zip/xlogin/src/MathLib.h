/*
* @author Jindřich Březina, Dominik Kotáb, Pavol Gumančík, Tomáš Moravčík
*
* @brief Interface of Math Library
*/

#ifndef MATH_LIB_H_
#define MATH_LIB_H_


/*
* @brief Adds two numbers
* @param a First number to add
* @param b Second number to add
* @return Returns a double which is equal to a+b
*/
double add(double a, double b);

/*
* @brief Subtracts second number from the first one
* @param a Number from which you subtract
* @param b Number you subtract with
* @return Returns a double which is equal to a-b
*/
double subtract(double a, double b);

/*
* @brief Multiplies two numbers
* @param a First number to multiply
* @param b Second number to multiply
* @return Returns a double which is equal to a*b
*/
double multiply(double a, double b);

/*
* @brief Divides second number from the first one
* @param a Number which you divide
* @param b Number you divide with
* @return Returns a double which is equal to a/b. If error occurs, 0 will be returned.
*/
double divide(double a, double b);

/*
* @brief Amplifies first number with the second one
* @param a Number which you amplify
* @param b Number you amplify with
* @return Returns a double which is equal to a^b
*/
double int_power(double a, int b);

/*
* @brief Amplifies first number with the second one.
* @param a Number which you amplify
* @param b Number you amplify with
* @return Returns a double which is equal to a^b
*/
double double_power(double a, double b);

/*
* @brief Just a function to help count power and root. Also a bonus function that
*        counts log with base "e".
* @param x Number which will be the log of (ln x).
* @return Returns log of x with base e.
*/
double cfrac_log(double x);

/*
* @brief Factorial of a number
* @param a Number which the factorial will be from
* @return Retruns a int which is equal to a!. If error occurs, 0 will be returned.
*/
long long int factorial(int a);

/*
* @brief Root of first number by second number
* @param a Number under the root
* @param b Index of root
* @return Returns a approximation of a root of first number by second number
*/
double root(double a, double b);

#endif /* end of include guard*/
