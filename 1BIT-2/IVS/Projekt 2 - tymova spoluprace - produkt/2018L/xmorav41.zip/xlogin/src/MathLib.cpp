/*
* @author Jindřich Březina, Dominik Kotáb, Pavol Gumančík, Tomáš Moravčík
*
* @brief Math Library
*/

#include <stdexcept>
#include <stdlib.h>
#include <stdio.h>
#include <cmath>

#include "MathLib.h"

double add(double a, double b){
  return a + b;
}

double subtract(double a, double b){
  return a - b;
}

double multiply(double a, double b){
  return a * b;
}

double divide(double a, double b){
  if(b == 0){
    //throw new std::runtime_error("Can't divide by 0.\n");
    return 0;
  }
  else{
    return a / b;
  }
}

double cfrac_log(double x){
    unsigned int n = 1000;
    double z = (x - 1) / (x + 1);
    double t = 1.0;

    //pocita "pozpatku" == od posledniho jmenovatele
    while(n >= 1){
        t = ((2 * n) - 1) - ((n*n)*(z*z)) / t;
        n--;
    }

    t = (2 * z) / t;

    return t;
}

double int_power(double a, int b){
  if(b == 0 && a == 0){
    return 0;
  }

  if(a == 0){
      return 0;
  }

  double sum = 1;

  if(b < 0){
    b = -b;
    for(int i = 0; i < b; i++){
      sum = sum * a;
    }
    return (1 / sum);
  }


  for(int i = 0; i < b; i++){
    sum = sum * a;
  }
  return sum;
}

double double_power(double a, double b){
  if(b == 0 && a == 0){
    //throw new std::runtime_error("Can't count 0^0.\n");
    return 0;
  }

  if(b == 0){
      return 1;
  }

  if(a == 0){
      return 0;
  }

  return pow(a, b);
  /*
  double sum = 1.0;
  double t = 1.0;
  double lna = cfrac_log(a);

  for(unsigned int i = 1; i <= 100; i++){
      t = t * ((b * lna) / i);
      sum += t;
  }

  return sum;*/
}

long long int factorial(int a){
  /*if(a % 1 != 0){
    throw new std::runtime_error("Can't make factorial from .\n");
    return 0;
  }*/
  if(a < 0){
    //throw new std::runtime_error("Can't make factorial from negative number.\n");
    return 0;
  }

  if(a == 0){
    return 1;
  }

  long long int result = 1;
  for(int i = 1; i <= a; i++){
    result = result * i;
  }
  return result;
}

double root(double a, double b){
  b = 1/b;
  return double_power(a, b);
}
