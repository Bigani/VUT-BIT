/*
* @author Jindřich Březina, Dominik Kotáb, Pavol Gumančík, Tomáš Moravčík
*
* @brief Math Library
*/
#include "gtest/gtest.h"
#include "MathLib.cpp"
#include <vector>


class Numbers : public::testing::Test
{
protected:
};

TEST_F(Numbers, add){
  EXPECT_EQ(add(1,2), 3);
  EXPECT_EQ(add(-1,-8), -9);
  EXPECT_EQ(add(1,-8), -7);
  EXPECT_EQ(add(-1,8), 7);
  //EXPECT_EQ(add(1.4,2.3), 3.7);
  EXPECT_EQ(add(100000000000,100000000000), 200000000000);
}

TEST_F(Numbers, subtract){
  EXPECT_EQ(subtract(1, 1), 0);
  EXPECT_EQ(subtract(1, 2), -1);
  EXPECT_EQ(subtract(2, 1), 1);
  EXPECT_EQ(subtract(1, -1), 2);
  EXPECT_EQ(subtract(-1, 1), -2);
  EXPECT_EQ(subtract(100000000000, 200000000000), -1e+11);
  EXPECT_EQ(subtract(1.8, 1.1), 0.7);
}

TEST_F(Numbers, multiply){
  EXPECT_EQ(multiply(1, 1), 1);
  EXPECT_EQ(multiply(1, -1), -1);
  EXPECT_EQ(multiply(-1, 1), -1);
  EXPECT_EQ(multiply(2, 3), 6);
  EXPECT_EQ(multiply(-2, -3), 6);
  EXPECT_EQ(multiply(1000000, 1000000), 1000000000000);
}

TEST_F(Numbers, divide){
  EXPECT_EQ(divide(1, 1), 1);
  EXPECT_EQ(divide(2, 1), 2);
  EXPECT_EQ(divide(1, 2), 0.5);
  EXPECT_EQ(divide(0.5, 2), 0.25);
  EXPECT_EQ(divide(-1, 1), -1);
  EXPECT_EQ(divide(1, -1), -1);
  EXPECT_EQ(divide(-1, -1), 1);
  EXPECT_EQ(divide(0, 1), 0);
  EXPECT_EQ(divide(1, 0), 0);
}

TEST_F(Numbers, int_power){
  EXPECT_EQ(int_power(2, 3), 8);
  EXPECT_EQ(int_power(2, -1), 0.5);
  EXPECT_EQ(int_power(0, 3), 0);
  EXPECT_EQ(int_power(2, 0), 1);
  EXPECT_EQ(int_power(200, 2), 40000);
  EXPECT_EQ(int_power(2, -2), 0.25);
  EXPECT_EQ(int_power(-2, 0), 1);
  EXPECT_EQ(int_power(-2, 3), -8);
  EXPECT_EQ(int_power(-2, 2), 4);
  EXPECT_EQ(int_power(-2, 4), 16);
}

TEST_F(Numbers, double_power){
  EXPECT_EQ(double_power(2, 3), 8);
  EXPECT_EQ(double_power(2, -1), 0.5);
  EXPECT_EQ(double_power(0, 3), 0);
  EXPECT_EQ(double_power(2, 0), 1);
  EXPECT_EQ(double_power(200, 2), 40000);
  EXPECT_EQ(double_power(2, -2), 0.25);
  EXPECT_EQ(double_power(-2, 0), 1);
  EXPECT_EQ(double_power(-2, 3), -8);
  EXPECT_EQ(double_power(-2, 2), 4);
  EXPECT_EQ(double_power(-2, 4), 16);
  EXPECT_EQ(double_power(-2, 4), 16);
}

TEST_F(Numbers, factorial){
  EXPECT_EQ(factorial(4), 24);
  EXPECT_EQ(factorial(1), 1);
  EXPECT_EQ(factorial(0), 1);
  EXPECT_EQ(factorial(-1), 0);
  EXPECT_EQ(factorial(10), 3628800);
}

TEST_F(Numbers, root){
  EXPECT_EQ(root(16, 2), 4);
  EXPECT_EQ(root(16, 4), 2);
  EXPECT_EQ(root(900, 2), 30);
  EXPECT_EQ(root(256, 4), 4);
  EXPECT_EQ(root(0.25, 2), 0.5);
}

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
