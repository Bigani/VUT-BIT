/*
* @author Jindřich Březina, Dominik Kotáb, Pavol Gumančík, Tomáš Moravčík
*
* @brief Profiling of math library.
*/

#include <stdlib.h>
#include <stdio.h>
#include <iostream>

#include "MathLib.h"

int main(){
  double input, result, help_var;
  int n = 0;
  double input_sum = 0;
  double input_square_sum = 0;


  while (std::cin >> input) {
    n = add(n, 1);
    input_sum = add(input_sum, input);
    input = int_power(input, 2);
    input_square_sum = add(input_square_sum, input);
  }

  help_var = divide(input_sum, n);
  help_var = int_power(help_var, 2);
  help_var = multiply(n, help_var);
  help_var = subtract(input_square_sum, help_var);

  result = subtract(n, 1);
  result = divide(1, result);
  result = multiply(result, help_var);
  result = root(result, 2);

  printf("%f\n", result);

  return 0;
}
