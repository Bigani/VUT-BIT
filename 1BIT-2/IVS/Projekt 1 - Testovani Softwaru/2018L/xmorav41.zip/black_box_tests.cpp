//======== Copyright (c) 2017, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     Red-Black Tree - public interface tests
//
// $NoKeywords: $ivs_project_1 $black_box_tests.cpp
// $Author:     Tomáš Moravčík <xmorav41@stud.fit.vutbr.cz>
// $Date:       $2019-02-20
//============================================================================//
/**
 * @file black_box_tests.cpp
 * @author Tomáš Moravčík
 *
 * @brief Implementace testu binarniho stromu.
 */

#include <vector>

#include "gtest/gtest.h"

#include "red_black_tree.h"

//============================================================================//
// ** ZDE DOPLNTE TESTY **
//
// Zde doplnte testy Red-Black Tree, testujte nasledujici:
// 1. Verejne rozhrani stromu
//    - InsertNode/DeleteNode a FindNode
//    - Chovani techto metod testuje pro prazdny i neprazdny strom.
// 2. Axiomy (tedy vzdy platne vlastnosti) Red-Black Tree:
//    - Vsechny listove uzly stromu jsou *VZDY* cerne.
//    - Kazdy cerveny uzel muze mit *POUZE* cerne potomky.
//    - Vsechny cesty od kazdeho listoveho uzlu ke koreni stromu obsahuji
//      *STEJNY* pocet cernych uzlu.


class EmptyTree : public ::testing::Test{
protected:

    BinaryTree Tree = BinaryTree();
};

TEST_F(EmptyTree, InsertNode)
{
    std::pair<bool, Node_t *> Pair1 = Tree.InsertNode(5);

    EXPECT_TRUE(Pair1.first);
    EXPECT_TRUE(Pair1.second->pParent == NULL);
    EXPECT_TRUE(Pair1.second->pLeft != NULL);
    EXPECT_TRUE(Pair1.second->pRight != NULL);
    EXPECT_TRUE(Pair1.second->color == BLACK);
    EXPECT_TRUE(Pair1.second->key == 5);

    EXPECT_TRUE(Pair1.second->pLeft->pParent == Pair1.second);
    EXPECT_TRUE(Pair1.second->pRight->pParent == Pair1.second);
    EXPECT_TRUE(Pair1.second->pRight->pRight == NULL);
    EXPECT_TRUE(Pair1.second->pRight->pLeft == NULL);
    EXPECT_TRUE(Pair1.second->pLeft->pLeft == NULL);
    EXPECT_TRUE(Pair1.second->pLeft->pRight == NULL);

    EXPECT_TRUE(Pair1.second->pRight->color == BLACK);
    EXPECT_TRUE(Pair1.second->pLeft->color == BLACK);

    std::pair<bool, Node_t *> Pair2 = Tree.InsertNode(5);
    EXPECT_FALSE(Pair2.first);
    EXPECT_TRUE(Pair1.second == Pair2.second);

    std::pair<bool, Node_t *> Pair3 = Tree.InsertNode(10);
    EXPECT_TRUE(Pair3.second->pParent == Pair1.second);

}

TEST_F(EmptyTree, DeleteNode)
{
    EXPECT_FALSE(Tree.DeleteNode(0));
    EXPECT_FALSE(Tree.DeleteNode(5));
    EXPECT_FALSE(Tree.DeleteNode(10));
    EXPECT_FALSE(Tree.DeleteNode(1500));

}

TEST_F(EmptyTree, FindNode)
{
    std::pair<bool, Node_t *> Pair1 = Tree.InsertNode(5);
    EXPECT_TRUE(Tree.FindNode(5) == Pair1.second);
    EXPECT_FALSE(Tree.FindNode(50) == Pair1.second);
    EXPECT_TRUE(Tree.FindNode(50) == NULL);

}

class NonEmptyTree : public ::testing::Test{
protected:

    BinaryTree Tree = BinaryTree();
    virtual void SetUp() {
        int values[] = { 2, 4, 8, 32, 16, 64, 256, 128, 512, 1024, 2048, 100, 500, 800 };

        for(int i = 0; i < 14; ++i){
            Tree.InsertNode(values[i]);
        }
    };
};

TEST_F(NonEmptyTree, InsertNode)
{
    std::pair<bool, Node_t *> Pair1 = Tree.InsertNode(5);
    EXPECT_NO_THROW(Pair1.second->pParent);
    std::pair<bool, Node_t *> Pair2 = Tree.InsertNode(256);
    EXPECT_FALSE(Pair2.first);

}

TEST_F(NonEmptyTree, DeleteNode)
{
    EXPECT_TRUE(Tree.DeleteNode(8));
    EXPECT_TRUE(Tree.DeleteNode(128));
    EXPECT_TRUE(Tree.DeleteNode(2048));

    EXPECT_FALSE(Tree.DeleteNode(50));
    EXPECT_FALSE(Tree.DeleteNode(123));
    EXPECT_FALSE(Tree.DeleteNode(128));

}

TEST_F(NonEmptyTree, FindNode)
{
    EXPECT_NO_THROW(Tree.FindNode(32));
    EXPECT_NO_THROW(Tree.FindNode(256));
    EXPECT_NO_THROW(Tree.FindNode(512));

    EXPECT_TRUE(Tree.FindNode(2) != NULL);
    EXPECT_TRUE(Tree.FindNode(4) != NULL);
    EXPECT_TRUE(Tree.FindNode(8) != NULL);

    EXPECT_TRUE(Tree.FindNode(12) == NULL);
    EXPECT_TRUE(Tree.FindNode(42) == NULL);
    EXPECT_TRUE(Tree.FindNode(92) == NULL);
}

class TreeAxioms : public ::testing::Test{
protected:

    BinaryTree Tree = BinaryTree();
};


TEST_F(TreeAxioms, Axiom1)
{

    std::vector<Node_t *> Leafs;
    Tree.GetLeafNodes(Leafs);
    for (int i = 0; i < Leafs.size(); i++){
        EXPECT_TRUE(Leafs[i]->color == BLACK);
    }


}


TEST_F(TreeAxioms, Axiom2)
{

    std::vector<Node_t *> NonLeafsNodes;
    Tree.GetNonLeafNodes(NonLeafsNodes);
    for (int i = 0; i < NonLeafsNodes.size(); i++){

        if (NonLeafsNodes[i]->color == RED) {
            EXPECT_TRUE(NonLeafsNodes[i]->pLeft->color == BLACK);
            EXPECT_TRUE(NonLeafsNodes[i]->pRight->color == BLACK);
        }

    }

}
TEST_F(TreeAxioms, Axiom3)
{
    int Count;
    int TotalCount = 0;

    std::vector<Node_t *> Leafs;
    Tree.GetLeafNodes(Leafs);
    Node_t *tempNode;

    for (int i = 0; i < Leafs.size(); i++){
        Count = 0;

        tempNode = Leafs[i];
        while(tempNode != Tree.GetRoot()){

            if (Leafs[i]->color == BLACK){
                Count++;
            }

            if (i == 0){
                TotalCount = Count;
            }

            EXPECT_TRUE(Count == TotalCount);

            tempNode = tempNode->pParent;
        }
    }
}


//============================================================================//

/*** Konec souboru black_box_tests.cpp ***/
