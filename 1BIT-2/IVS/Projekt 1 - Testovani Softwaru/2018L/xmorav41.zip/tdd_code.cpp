//======== Copyright (c) 2017, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     Test Driven Development - priority queue code
//
// $NoKeywords: $ivs_project_1 $tdd_code.cpp
// $Author:     Tomáš Moravčík <xmorav41@stud.fit.vutbr.cz>
// $Date:       $2019-02-20
//============================================================================//
/**
 * @file tdd_code.cpp
 * @author Tomáš Moravčík
 *
 * @brief Implementace metod tridy prioritni fronty.
 */

#include <stdlib.h>
#include <stdio.h>

#include "tdd_code.h"

//============================================================================//
// ** ZDE DOPLNTE IMPLEMENTACI **
//
// Zde doplnte implementaci verejneho rozhrani prioritni fronty (Priority Queue)
// 1. Verejne rozhrani fronty specifikovane v: tdd_code.h (sekce "public:")
//    - Konstruktor (PriorityQueue()), Destruktor (~PriorityQueue())
//    - Metody Insert/Remove/Find a GetHead
//    - Pripadne vase metody definovane v tdd_code.h (sekce "protected:")
//
// Cilem je dosahnout plne funkcni implementace prioritni fronty implementovane
// pomoci tzv. "double-linked list", ktera bude splnovat dodane testy
// (tdd_tests.cpp).
//============================================================================//

PriorityQueue::PriorityQueue()
{
    //Ak prazdna fronta
    koren = NULL;
}

PriorityQueue::~PriorityQueue()
{
    Element_t *element = GetHead();
    //Prechod od zaciatku do konca
    while (element != NULL){
        Element_t *tempElement = element;
        element = element->pNext;
        delete tempElement;
    }
}


void PriorityQueue::Insert(int value)
{
    //Prechod prvkami
    for (Element_t *element = GetHead(); element != NULL; element = element->pNext){
        //ak jediny prvok v zozname
        if (element->pPrev == NULL && element->pNext == NULL) {
            //hodnota elementu je vyssia nez hodnota vkladaneho prvku
            if (element->value > value){
                koren = NewElement(value,NULL,element);//(element,NULL,value);
                element->pPrev = koren;
            }
            //hodnota nizsia || rovna
            else {
                //na koniec
                element->pNext = NewElement(value,element,NULL);//(NULL,element,value);
            }
            return;
        }

        //Pre viac prvkov
        else if(element->pPrev == NULL && element->pNext != NULL){
            //hodnota elemntu je vacsia nez vkladana
            if (element->value > value) {
                //prvok pojde na zaciatok
                koren = NewElement(value,NULL,element);//(element,NULL,value);
                element->pPrev = koren;
                return;
            }
        }

        //Prvok ide do niekam do stredu zoznamu
        else if (element->value >= value && element->pPrev->value <= value){
            //vkladame medzi predchadazjucim a aktualnym
            Element_t *insElement = NewElement(value,element->pPrev,element);//(element,element->pPrev,value);
            element->pPrev->pNext = insElement;
            element->pPrev = insElement;
            return;
        }

        //Na poslednom z viacerych prvkov
        else if(element->pPrev != NULL && element->pNext == NULL){
            if (element->value > value){
                //vkladame na predposledne miesto
                element->pPrev->pNext = NewElement(value,element->pPrev,element);//(element,element->pPrev,value);
                element->pPrev = element->pPrev->pNext;
            }

            else {
                //vkladame na koniec
                element->pNext = NewElement(value,element,NULL);//(NULL,element,value);
            }
            return;
        }
    }
    //zoznam je prazndy, prvok vkladany na zaciatok
    koren = NewElement(value,NULL,NULL);//(NULL,NULL,value);
}

bool PriorityQueue::Remove(int value)
{
    if (Element_t *element = Find(value)){

        //Ak prvy prvok
        if (element->pPrev == NULL && element->pNext != NULL){
            //Nasledujuceho elementu pPrev pointer bude ukazovat NULL
            element->pNext->pPrev = NULL;
            //Prvy bude nasledujuci
            koren = element->pNext;
            delete element;
        }

        //Ak posledny
        else if (element->pPrev != NULL && element->pNext == NULL) {
            //Predchadzajuci element ukaze na NULL
            element->pPrev->pNext = NULL;
            delete element;
        }

        //Ak v strede
        else if (element->pPrev != NULL && element->pNext != NULL){
            //Ukazovatele skipnu aktualny element
            element->pPrev->pNext = element->pNext;
            element->pNext->pPrev = element->pPrev;
            delete element;
        }
        //Ak jediny v zozname
        else if (element->pPrev == NULL && element->pNext == NULL){
            koren = NULL;
            delete element;
        }
        return true;
    }
    //zoznam neobsahuje prvok
    return false;
}

PriorityQueue::Element_t *PriorityQueue::Find(int value)
{
    for (Element_t *element = GetHead(); element != NULL; element = element->pNext){
        if (element->value == value)
            return element;
    }
    //ak nie je taky element
    return NULL;
}

PriorityQueue::Element_t *PriorityQueue::GetHead()
{
    return koren;
}


PriorityQueue::Element_t *PriorityQueue::NewElement(int value, Element_t *pPrev, Element_t *pNext)
{
    Element_t *element = new Element_t();
    element->value = value;
    element->pPrev = pPrev;
    element->pNext = pNext;

    return element;
}

/*** Konec souboru tdd_code.cpp ***/
