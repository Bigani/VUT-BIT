//======== Copyright (c) 2017, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     White Box - Tests suite
//
// $NoKeywords: $ivs_project_1 $white_box_code.cpp
// $Author:     Tomáš Moravčík <xmorav41@stud.fit.vutbr.cz>
// $Date:       $2017-01-04
//============================================================================//
/**
 * @file white_box_tests.cpp
 * @author Tomáš Moravčík
 *
 * @brief Implementace testu prace s maticemi.
 */

#include <math.h>
#include <vector>

#include "gtest/gtest.h"
#include "white_box_code.h"


//============================================================================//


namespace WhiteBoxTesting{

    using namespace ::testing;

    class TestMatrix : public ::testing::Test
    {
    protected:

        Matrix matrix;


        Matrix a1x1Matrix()
        {
            return Matrix();
        }

        void ini1x1Matrix()
        {
            matrix = a1x1Matrix();
        }

        Matrix a1x2Matrix()
        {
            Matrix matrix = Matrix(1,2);
            matrix.set(std::vector<std::vector<double>> {
                    {1, 4},
            });

            return matrix;
        }

        void ini1x2Matrix()
        {
            matrix = a1x2Matrix();
        }

        Matrix a2x1Matrix()
        {
            Matrix matrix = Matrix(2,1);
            matrix.set(std::vector<std::vector<double>> {
                    {3},
                    {5},
            });

            return matrix;
        }

        void ini2x1Matrix()
        {
            matrix = a2x1Matrix();
        }


        Matrix a4x4Matrix()
        {
            Matrix matrix = Matrix(4,4);
            matrix.set(std::vector<std::vector<double>> {
                    {8, 2, 150, -7.7},
                    {-11, 42, -347, 90.90},
                    {0, 1.1245, -3.4561, 0},
                    {14.55, 12.0, -58, 1},
            });

            return matrix;
        }

        Matrix test4x4Matrix()
        {
            Matrix matrix = Matrix(4,4);
            matrix.set(std::vector<std::vector<double>> {
                    {1,2,0,1},
                    {2,2,2,2},
                    {0,1,2,3},
                    {1,2,2,1},
            });

            return matrix;
        }

        void ini4x4Matrix()
        {
            matrix = a4x4Matrix();
        }


    };


    TEST_F(TestMatrix, Construct){

        EXPECT_NO_THROW(Matrix());
        EXPECT_NO_THROW(Matrix(1,1));
        EXPECT_NO_THROW(Matrix(5,5));
        EXPECT_NO_THROW(Matrix(25,52));
        EXPECT_NO_THROW(Matrix(2345,3245));

        EXPECT_ANY_THROW(Matrix(-1,-1));
        EXPECT_ANY_THROW(Matrix(0,0));
        EXPECT_ANY_THROW(Matrix(100,0));
        EXPECT_ANY_THROW(Matrix(5,-5));
    }

    TEST_F(TestMatrix, ValueOn1x1Matrix){

        ini1x1Matrix();

        EXPECT_TRUE(matrix.set(0,0,0));
        EXPECT_TRUE(matrix.set(0,0,100));
        EXPECT_TRUE(matrix.set(0,0,-100));
        EXPECT_TRUE(matrix.set(0,0,50.05));
        EXPECT_TRUE(matrix.set(0,0,-50.05));

        EXPECT_FALSE(matrix.set(1,1,1));
        EXPECT_FALSE(matrix.set(0,1,0));
        EXPECT_FALSE(matrix.set(2,0,3000));
        EXPECT_FALSE(matrix.set(3,-3,3));
        EXPECT_FALSE(matrix.set(42,42,-3000));

    }


///
    TEST_F(TestMatrix, ValueOn4x4Matrix){

        matrix = a4x4Matrix();

        EXPECT_TRUE(matrix.set(0,0,1));
        EXPECT_TRUE(matrix.set(3,3,10));
        EXPECT_TRUE(matrix.set(1,2,-4.584));
        EXPECT_TRUE(matrix.set(0,2,8.78));

        EXPECT_FALSE(matrix.set(4,4,1));
        EXPECT_FALSE(matrix.set(1,4,-5));
        EXPECT_FALSE(matrix.set(5000,5000,5000));
        EXPECT_FALSE(matrix.set(80,80,8.456));

    }

    TEST_F(TestMatrix, ValuesOn1x1Matrix){

        ini1x1Matrix();

        EXPECT_TRUE(matrix.set(std::vector<std::vector<double>> {{0}}));
        EXPECT_TRUE(matrix.set(std::vector<std::vector<double>> {{99999}}));
        EXPECT_TRUE(matrix.set(std::vector<std::vector<double>> {{-99999}}));
        EXPECT_TRUE(matrix.set(std::vector<std::vector<double>> {{999.999}}));
        EXPECT_TRUE(matrix.set(std::vector<std::vector<double>> {{-999.999}}));


        EXPECT_FALSE(matrix.set(std::vector<std::vector<double>> {{0,0},{0}}));
    }

    TEST_F(TestMatrix, ValueOn1x2Matrix){

        ini1x2Matrix();

        EXPECT_TRUE(matrix.set(std::vector<std::vector<double>>{
            {1,2},
        }));

        EXPECT_FALSE(matrix.set(std::vector<std::vector<double>>{
            {1,2,5,6},
        }));

        EXPECT_FALSE(matrix.set(std::vector<std::vector<double>>{
            {1,2},
            {5,6},
        }));
        }


    TEST_F(TestMatrix, ValueOn2x1Matrix){

        ini2x1Matrix();

        EXPECT_TRUE(matrix.set(std::vector<std::vector<double>>{
            {1},
            {2},
        }));

        EXPECT_FALSE(matrix.set(std::vector<std::vector<double>>{
            {1,5},
        }));

        EXPECT_FALSE(matrix.set(std::vector<std::vector<double>>{
            {1},
            {5},
            {8},
        }));
        }


    TEST_F(TestMatrix, ValuesOn4x4Matrix){

        ini4x4Matrix();

        EXPECT_TRUE(matrix.set(std::vector<std::vector<double>> {
            {155,-350,20.58,0},
            {0,0,0,1},
            {-2.47,-13.1444,1500,28},
            {9.8,-5.4,21,-36},
        }));

        EXPECT_FALSE(matrix.set(std::vector<std::vector<double>> {
        {155,-350,20.58,0},
        {0,0,0,1,0},
        {-2.47,-13.1444,28},
        {9.8,-5.4}, {21,-36},
        }));
    }
///
    TEST_F(TestMatrix, getValue1x1Matrix){
        ini1x1Matrix();

        EXPECT_ANY_THROW(matrix.get(1, 1));
        EXPECT_ANY_THROW(matrix.get(4567,5464));

        EXPECT_NO_THROW(matrix.set(0, 0, 0));
        }
///
    TEST_F(TestMatrix, getValue4x4Matrix){
        ini4x4Matrix();

        EXPECT_ANY_THROW(matrix.get(255, 55));
        EXPECT_ANY_THROW(matrix.get(1, 5));
        EXPECT_ANY_THROW(matrix.get(4, 4));

        EXPECT_NO_THROW(matrix.set(1, 2, 10));
        EXPECT_NO_THROW(matrix.set(3, 0, 99.99));
        EXPECT_NO_THROW(matrix.set(2, 2, -99.99));
        }

    TEST_F(TestMatrix, Addition){

        Matrix Matrix1x1 = a1x1Matrix();
        Matrix Matrix4x4 = test4x4Matrix();
        Matrix Matrix1x2 = a1x2Matrix();

        //Súčet matíc s rôznou veľkosťou
        EXPECT_ANY_THROW(Matrix1x1 + Matrix4x4);
        EXPECT_ANY_THROW(Matrix1x1 + Matrix1x2);
        EXPECT_ANY_THROW(Matrix1x2 + Matrix4x4);

        //Súčet matíc
        Matrix test1 = Matrix4x4 + Matrix4x4;
        Matrix sum1 = Matrix(4, 4);
        sum1.set(std::vector<std::vector<double>> {
        {2,4,0,2},
        {4,4,4,4},
        {0,2,4,6},
        {2,4,4,2},
        });

        EXPECT_TRUE(test1 == sum1);

        Matrix test2 = Matrix1x2 + Matrix1x2;
        Matrix sum2 = Matrix(1,2);
        sum2.set(std::vector<std::vector<double>> {
        {2,8},
        });

        EXPECT_TRUE(test2 == sum2);
    }
///
    TEST_F(TestMatrix, Multiplication){
        Matrix Matrix1x1 = a1x1Matrix();
        Matrix Matrix4x4 = test4x4Matrix();
        Matrix Matrix1x2 = a1x2Matrix();
        Matrix Matrix2x1 = a2x1Matrix();

        EXPECT_ANY_THROW(Matrix1x1 * Matrix4x4);

        //Súčin matíc
        Matrix test1 = Matrix4x4 * Matrix4x4;
        Matrix product1 = Matrix(4, 4);

        product1.set(std::vector<std::vector<double>> {
        {6,8,6,6},
        {8,14,12,14},
        {5,10,12,11},
        {6,10,10,12},
        });

        EXPECT_TRUE(test1 == product1);

        Matrix test2 = Matrix1x2 * Matrix2x1;
        Matrix product2 = Matrix();

        product2.set(std::vector<std::vector<double>> {
        {23},
        });

        EXPECT_TRUE(test2 == product2);

        Matrix test3 = Matrix2x1 * Matrix1x2;
        Matrix product3 = Matrix(2, 2);

        product3.set(std::vector<std::vector<double>> {
        {3,12},
        {5,20},
        });

        EXPECT_TRUE(test3 == product3);

    }

    TEST_F(TestMatrix, IsEqual){
        Matrix Matrix1x1 = a1x1Matrix();
        Matrix Matrix4x4 = a4x4Matrix();
        Matrix Matrix1x2 = a1x2Matrix();
        Matrix Matrix2x3 = Matrix(2,3);
        Matrix Matrix5x10 = Matrix(5,10);

        EXPECT_TRUE(Matrix1x1 == Matrix1x1);
        EXPECT_TRUE(Matrix1x2 == Matrix1x2);
        EXPECT_TRUE(Matrix4x4 == Matrix4x4);

        EXPECT_ANY_THROW(Matrix1x1 == Matrix4x4);
        EXPECT_ANY_THROW(Matrix1x2 == Matrix4x4);
        EXPECT_ANY_THROW(Matrix1x1 == Matrix1x2);

        EXPECT_ANY_THROW(Matrix2x3 == Matrix5x10);

        Matrix MatrixA = Matrix();
        Matrix MatrixB = Matrix();
        MatrixA.set(0,0,42);
        MatrixB.set(0,0,420);

        EXPECT_FALSE(MatrixA == MatrixB);


    }
///
    TEST_F(TestMatrix, MultiplicationByCon){
        Matrix Matrix1x1 = a1x1Matrix();
        Matrix Matrix4x4 = test4x4Matrix();
        Matrix Matrix1x2 = a1x2Matrix();

        Matrix test1 = Matrix1x1 * 100;
        Matrix product1 = Matrix();

        EXPECT_TRUE(test1 == product1);

        Matrix test2 = Matrix4x4 * 5;
        Matrix product2 = Matrix(4,4);
        product2.set(std::vector<std::vector<double>> {
        {5,10,0,5},
        {10,10,10,10},
        {0,5,10,15},
        {5,10,10,5},
        });

        EXPECT_TRUE(test2 == product2);

        Matrix test3 = Matrix1x2 * 0;
        Matrix product3 = Matrix(1,2);
        product2.set(std::vector<std::vector<double>> {
        {0,0},
        });

        EXPECT_TRUE(test3 == product3);
    }

///
    TEST_F(TestMatrix, SolveEquation1){
        matrix = Matrix();
        matrix.set(0,0,1);
        EXPECT_NO_THROW(matrix.solveEquation(std::vector<double> {1}));

        Matrix matrixF = Matrix(2,3);
        EXPECT_ANY_THROW(matrixF.solveEquation(std::vector<double> {10,15,16}));

        matrix = Matrix(2,2);
        matrix.set(std::vector<std::vector<double>>{
            {4,5},
            {6,7},
        });
        EXPECT_NO_THROW(matrix.solveEquation(std::vector<double> {2,3}));

        matrix = Matrix(3,3);
        matrix.set(std::vector<std::vector<double>>{
        {2,5,8},
        {6,7,11},
        {7,1,0},
        });
        EXPECT_NO_THROW(matrix.solveEquation(std::vector<double> {2,3,8}));

        matrix = Matrix(5,5);
        matrix.set(std::vector<std::vector<double>>{
            {2,3,4,5,6},
            {4,5,6,8,5},
            {10,4,5,8,9},
            {7,8,9,5,4},
            {3,3,3,14,15},
         });
        EXPECT_NO_THROW(matrix.solveEquation(std::vector<double> {10,11,12,13,14}));



        matrix = Matrix(2,2);
        matrix.set(std::vector<std::vector<double>>{
            {2,4},
            {2,4},
        });
        EXPECT_ANY_THROW(matrix.solveEquation(std::vector<double> {1,4}));

        matrix = Matrix(5,5);
        matrix.set(std::vector<std::vector<double>>{
            {1,2,3,4,5},
            {6,7,8,9,10},
            {11,12,13,14,15},
            {16,17,18,19,20},
            {21,22,23,24,25},
        });
        EXPECT_ANY_THROW(matrix.solveEquation(std::vector<double> {10,11,12,13,14,15}));
}


}






//============================================================================//

/*** Konec souboru white_box_tests.cpp ***/
